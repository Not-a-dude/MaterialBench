# BCR Configuration

This directory contains configuration information for BCR. It is patterned after
the [Publish to BCR app](https://github.com/bazel-contrib/publish-to-bcr/tree/main/templates),
which we have [opted not to use](https://github.com/bazel-contrib/publish-to-bcr/issues/157).
However, `presubmit.yml` is used by [our own BCR tooling](../docs/releasing.md).
